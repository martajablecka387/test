#from GAME import *


fil = open('Desktop\P-upggift\docx\listan.txt')

filstr = fil.read()
ordlista =filstr.split()
ordlista =open(...).read().split()

print(ordlista)




#best_doc.save('best.docx') 

