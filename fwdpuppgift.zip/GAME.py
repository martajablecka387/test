import pygame 
import random
from os import path 
import time
from FINAL_PLACE_A_SHIP import *

NAME = "NEW PLAYER"
#NAME = input("To begin Battleships game please enter you name: ")

#SCREEN
WIDTH = 800
HEIGHT = 600
FPS = 30 #how many times per second the screen will be updated

#COLORS
WHITE=(255,255,255)
BLACK=(0,0,0)
ORANGE = (165,45,45)
BLUE1=(25,25,112)
BLUE=(100,149,237)
RED=(255,0,0)
PINK=(139,69,19)
YELLOW=(255,215,0)
GREEN=(0,100,0)
GRAY=(49,79,79)

#STARTPOINTS:
points = 0
n_sank = 0
n_rem =5-n_sank

#-------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------

# INITIALIZE PYGAME AND MODULS
pygame.init()
pygame.font.init()                      
screen= pygame.display.set_mode((WIDTH,HEIGHT))
pygame.display.set_caption("Sänka skepp")
clock = pygame.time.Clock()     #how fast we going


#IMAGES 
art_dir = path.join(path.dirname(__file__), "images")
backround = pygame.image.load(path.join(art_dir,"Underwater Resized 600x800.jpg")).convert()
backround_rect = backround.get_rect()
PatrolBoat = pygame.image.load(path.join(art_dir,"PatrolBoat.png")).convert()
bomb = pygame.image.load(path.join(art_dir,"000.png")).convert()
liquidWater = pygame.image.load(path.join(art_dir,"liquidWater.png")).convert()
explosion = pygame.image.load(path.join(art_dir,"007.png")).convert()


#TEXT FUNCTION
font_name = pygame.font.match_font("Impact")
def text(surface, color, text, size, x,y):
    font = pygame.font.Font(font_name, size)
    text_surface = font.render(text,True, color)
    text_rect = text_surface.get_rect()
    text_rect.topleft = (x,y)
    surface.blit(text_surface,text_rect)

def OBStext(obs_text,time,color,x):
    text(screen, color,obs_text,40,x,HEIGHT/2-100)
    pygame.display.update()
    pygame.time.wait(time)
    

#--------------------------------------------------------------------------------------------------
        #****SPRITS CLASSES****#
#--------------------------------------------------------------------------------------------------

#battelships are allowed only on the game board
#board: startpoint (40,40), width = 560, height = 440
class Battleships(pygame.sprite.Sprite): #DELETE?
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((1,1))
        self.image.fill(BLUE)
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y

    def update(self):
        self.speedx = 0
        self.speedy = 0

class Realships(pygame.sprite.Sprite):
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((20,20))
        self.image.fill(BLUE)
        self.rect = self.image.get_rect()
        self.rect.centerx=x
        self.rect.centery=y

    def update(self):
        self.speedx = 0
        self.speedy = 0
        
class Player(pygame.sprite.Sprite): #BOMB
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        #self.image= pygame.image.load(path.join(art_dir,"000.png")).convert()
        self.image = pygame.transform.scale(bomb,(60,60))
        self.image.set_colorkey(BLACK)
        #self.image = pygame.Surface((40,40))
        #self.image.fill(GREEN)
        self.rect = self.image.get_rect()
        self.rect.centery = 70
        self.rect.centerx = 70

        self.speedx = 0
        self.speedy = 0

    def move(self,x,y):
        self.rect.centerx +=x
        self.rect.centery +=y
    
    def update(self):
        self.speedx = 0
        self.speedy = 0

        #keystate=pygame.mouse.get_pressed()
        keystate=pygame.key.get_pressed()


        if keystate[pygame.K_LEFT]:
            self.move(-60,0)
            pygame.time.wait(100)
        elif keystate[pygame.K_RIGHT]:
            self.move(60,0)
            pygame.time.wait(100)
        elif keystate[pygame.K_DOWN]:
            self.move(0,60)
            pygame.time.wait(100)
        elif keystate[pygame.K_UP]:
            self.move(0,-60)
            pygame.time.wait(100)
      
#game board: startpoint (40,40), width = 440, height = 440
        if self.rect.left < 40:
            self.rect.left = 40
        elif self.rect.right > 460:
            self.rect.right = 460
        elif self.rect.top < 40:
            self.rect.top = 40
        elif self.rect.bottom > 580:
            self.rect.bottom = 580

        self.rect.x += self.speedx
        self.rect.y += self.speedy

    def sank_ship(self):
        visited = Visited(self.rect.centerx,self.rect.centery, PINK) #self.rect.bottom
        all_sprites.add(visited)
        all_visited.add(visited)

class Visited(pygame.sprite.Sprite):
    def __init__(self,x,y,color):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((50,50))
        self.image.fill(color)
        self.image.set_colorkey(color)
        self.rect = self.image .get_rect()
        self.rect.centery = y
        self.rect.centerx =x

    def update(self):
        self.speedx = 0
        self.speedy = 0

#------------------------------------------------------------------------------------------------------------------------------------------------
#                              #***CREATE SPRITES***#
#------------------------------------------------------------------------------------------------------------------------------------------------

#SPRITES GROUPS
all_sprites = pygame.sprite.Group()
all_ships = pygame.sprite.Group() #delete
all_visited = pygame.sprite.Group()
all_hitted_square = pygame.sprite.Group()#delete
all_players = pygame.sprite.Group()
all_rships = pygame.sprite.Group()



#CREATE SPRITES
player = Player()
all_players.add(player)

#CREATE "BATTELSHIPS"  --> DELETE
shipx=70
shipy=70
while shipy < 610:
    for shipx in range(70,490,60):
        ship=Battleships(shipx,shipy)
        all_ships.add(ship)
        all_sprites.add(ship)
    shipy +=60



#CREATE SHIPS
#place_a_ship output : [x,y, axis_orientation]
def create_ships(ship,size,ship_group):
    #70edge,60step
    maxx=(size+ship[0])*60+70
    maxy=(size+ship[1])*60+70

    x= (ship[0]*60)+70
    y= (ship[1]*60)+70

    if ship[2] == "vertical":
        while y < maxy:
            boat= Realships(x,y)
            all_rships.add(boat)
            all_sprites.add(boat)
            ship_group.add(boat)
            y+=60
            
    elif ship[2] == "horisontal":
        while x < maxx:
            boat= Realships(x,y)
            all_rships.add(boat)
            all_sprites.add(boat)
            ship_group.add(boat)
            x +=60

Ship5 = (place_a_ship(5))
Ship5_group=pygame.sprite.Group()
create_ships(Ship5,5,Ship5_group)
#print(Ship5)

Ship4 = (place_a_ship(4))
Ship4_group=pygame.sprite.Group()
create_ships(Ship4,4,Ship4_group)
#print(Ship4)

Ship3 = (place_a_ship(3))
Ship3_group=pygame.sprite.Group()
create_ships(Ship3,3,Ship3_group)
#print(Ship3)

Ship2 = (place_a_ship(2))
Ship2_group=pygame.sprite.Group()
create_ships(Ship2,2,Ship2_group)
#print(Ship2)

Ship1 = (place_a_ship(1))
Ship1_group=pygame.sprite.Group()
create_ships(Ship1,1,Ship1_group)
#print(Ship1)

#print("",free_spots[0],"\n",free_spots[1],"\n",free_spots[2],"\n",free_spots[3],"\n",free_spots[4],"\n",free_spots[5],"\n",free_spots[6],"\n",free_spots[7],"\n",free_spots[8],"\n")


#OCCUPIED SPACE AFTER A SHIP HAS BEEN SANK

def oc_space(ship_group,Ship,free_spots):
    row=len(free_spots)
    col=len(free_spots[0])
    if len(ship_group)==0:
        taken_list = taken(Ship[3],Ship[0],Ship[1],Ship[2])
        for element in taken_list:
            x=element[0]
            y=element[1]
            oc = Visited((x*60)+70,(y*60)+70,RED)
            oc.image =pygame.transform.scale(liquidWater,(50,50))
            oc.image.set_colorkey(WHITE)
            all_sprites.add(oc)
            all_hitted_square.add(oc)
        OBStext("CONGRATULATIONS! YOU SANK A SHIP",500,PINK,30)
        ship_group.add(unused_sprite)
    return ship_group


#--------------------------------------------------------------------------------------------------------
          #****ENTER THE GAME****#
#--------------------------------------------------------------------------------------------------------

running_first = True
while running_first:

    #ACTIONS
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            #pygame.quit()
            running_first==False
            break
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_2:
                running_first = False
            

    #DRAW SCREEN
    screen.fill(BLACK)
    screen.blit(backround, backround_rect)
    text(screen, YELLOW,"Welcome to Battelship " +NAME + " !!! ", 40, 20,20)
    text(screen, BLUE1,"Here is some useful information which will allow you", 20, 20,100)
    text(screen,BLUE1,"to enjoy the game even more. Move your bomb around the board using", 20, 20,140)
    text(screen,BLUE1,"the arrow keys. When your bomb is above the square you think a ship", 20, 20,180)
    text(screen,BLUE1,"may be hiding, try to sink it using space buttom. If you sink a ship", 20, 20,220)
    text(screen,BLUE1,"or hit a part of it with the bomb, you will see a flame.", 20, 20, 260)
    text(screen, ORANGE,"You get 10 points every time you hit a ship and an extra", 20, 20, 300)
    text(screen, ORANGE,"20 points when the whole ship is sunk. No hit will cost you 1 point", 20, 20, 340)
    text(screen, ORANGE,"Firing on the same location twice will cost you 5 points.", 20, 20,380)
    text(screen, ORANGE,"To  see the locations of the ships you can press 1,", 20, 20,420)
    text(screen, ORANGE,"but that will cost you 50 points!",20, 20, 470)
    text(screen, GREEN,"To continue to the game press 2.", 20, 20, 550)
    
    pygame.display.flip()

#-------------------------------------------------------------------------------------------------------------
         #****MAIN GAME****#
#-------------------------------------------------------------------------------------------------------------

running_game =True
while running_game:

    clock.tick(FPS) #so the loop run always at the same speed

    #ACTIONS
    all_sprites.update()
    all_players.update()

    hit = pygame.sprite.groupcollide(all_visited, all_rships, True,True)
    shoot = pygame.sprite.groupcollide(all_visited, all_ships,True, True)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            #pygame.quit()
            running_game==False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.sank_ship()
                if not hit: #and not shoot:
                    points -=1
                
            elif event.key == pygame.K_2:
                running_game = False
            elif event.key == pygame.K_1:
                points -=50
                b = []
                a = all_rships.sprites()
                for sprite in a:
                    sprite.image.fill(WHITE)
                    b.append(sprite)
                    if len(b)==len(a):
                        all_sprites.draw(screen)
                        pygame.display.flip()
                        pygame.time.delay(1000)
                        for sprite in a:
                            sprite.image.fill(BLUE)

    #rem - remains
    n_rem =5-n_sank 
    if hit:
        points +=11
        hitted_square=Visited(player.rect.centerx,player.rect.centery, BLACK)
        hitted_square.image =pygame.transform.scale(explosion,(40,50))
        hitted_square.image.set_colorkey(WHITE)
        all_hitted_square.add(hitted_square)
        all_sprites.add(hitted_square)
        unused_sprite=Player()

        if len(Ship5_group)==0: 
            points +=20
            oc_space(Ship5_group,Ship5,free_spots)
            n_sank +=1
        if len(Ship4_group)==0:
            points +=20
            oc_space(Ship4_group,Ship4,free_spots)
            n_sank +=1
        if len(Ship3_group)==0:
            points +=20
            oc_space(Ship3_group,Ship3,free_spots)
            n_sank +=1
        if len(Ship2_group)==0:
            points +=20
            oc_space(Ship2_group,Ship2,free_spots)
            n_sank +=1
        if len(Ship1_group)==0:
            points +=20
            oc_space(Ship1_group,Ship1,free_spots)
            n_sank +=1
    if n_rem==0:
        OBStext("GAME OVER",500,RED,100) 
        OBStext("PRESS 2 TO EXIT",500,GREEN,300)
        



    if shoot:
        hitted_square=Visited(player.rect.centerx,player.rect.centery, BLACK)
        hitted_square.image =pygame.transform.scale(liquidWater,(50,50))
        hitted_square.image.set_colorkey(WHITE)
        all_hitted_square.add(hitted_square)
        all_sprites.add(hitted_square)
   
    
    colision= pygame.sprite.groupcollide(all_hitted_square,all_visited,False,True)

    if colision:
        points -=4 
        OBStext("YOU CANNOT BOMB THE SAME SQUARE TWICE",2000,RED,30)
        



#DRAW SCREEN
    screen.fill(WHITE)
    screen.blit(backround, backround_rect)
    text(screen,ORANGE, "POINTS : " + str(points), 30,500,20)
    text(screen,GRAY, "NUMBER OF SUNK SHIPS : " + str(n_sank), 20,500,60)
    text(screen,GRAY, "NUMBER OF SHIPS REMAINING : " + str(n_rem), 20,500,90)
    text(screen,BLUE1, "USE THE ARROW KEYS TO MOVE", 20,500,400)
    text(screen, BLUE1,"TO SHOOT PRESS SPACE", 20, 500, 440)
    text(screen,BLUE1,"TO SEE BOATS PRESS 1",20, 500,480)
    text(screen, BLUE1,"TO EXIT PRESS 2", 20, 500, 520)

    #GameBoard(40,40)
    

#DRAW GAME BOARD

    height = 460
    width = 580
    game_board = pygame.draw.rect(screen,BLUE,(20,20,height,width))
    w=40
    h=40
    for i in range(10):
        pygame.draw.line(screen,WHITE,(40,w),(height,w),1)
        pygame.draw.line(screen,WHITE,(h,40),(h,width),1)
        w += 60
        h += 60
        if h > 460:
            h=460

#DRAW SPRITES
    all_sprites.draw(screen)
    all_players.draw(screen)

    pygame.display.flip() 

#-------------------------------------------------------------------------------------------------------
           #****EXIT GAME****#
#-------------------------------------------------------------------------------------------------------       

running_last = True
while running_last:

    #ACTIONS
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running_last = False
            break
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_2:
                running_last = False
                break

    #DRAWING THE SCREEN
    screen.fill(WHITE)
    screen.blit(backround, backround_rect)
    text(screen, BLUE1,"CONGRATULATIONS", 30, 20,20)
    text(screen, GRAY,"YOU RECIVED POINTS : " + str(points), 25, 20,60)
    #text(screen, ORANGE,"THE LIST OF 10 BEST PLAYERS:", 20, 20, 150)
    text(screen, GREEN,"TO EXIT PRESS 2", 20, 650, 550)

    pygame.display.flip()


#-------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------
pygame.quit()
