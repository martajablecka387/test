import random

free_spots=[ 
			 [0, 0, 0, 0, 0, 0, 0] #0
			,[0, 0, 0, 0, 0, 0, 0] #1
			,[0, 0, 0, 0, 0, 0, 0] #2
			,[0, 0, 0, 0, 0, 0, 0] #3
			,[0, 0, 0, 0, 0, 0, 0] #4
			,[0, 0, 0, 0, 0, 0, 0] #5
			,[0, 0, 0, 0, 0, 0, 0] #6
			,[0, 0, 0, 0, 0, 0, 0] #7
			,[0, 0, 0, 0, 0, 0, 0] #8
	    	]#0  1  2  3  4  5  6

#row=len(free_spots) 9
#col=len(free_spots[0]) 7
#print(row,col)


# def taken is putting number 1 on the board in places taken by a ship and nuber 2 i 
# places around it. 
def taken(size,x,y,axis_orientation):
	row=len(free_spots)
	col=len(free_spots[0])
	b=size+y
	a=size+x
	taken_list=[]
	if axis_orientation=="horisontal":
		if x>0:
			free_spots[y][x-1]=2
			taken_list.append([x-1,y])
			if y >0:
				free_spots[y-1][x-1]=2
				taken_list.append([x-1,y-1])
			if y <row-1:
				free_spots[y+1][x-1]=2
				taken_list.append([x-1,y+1])
		if a<=col-1:
			free_spots[y][a]=2
			taken_list.append([a,y])
			if y >0:
				free_spots[y-1][a]=2
				taken_list.append([a,y-1])
			if y <row-1:
				free_spots[y+1][a]=2
				taken_list.append([a,y+1])
		while x<a:
			free_spots[y][x]=1
			if y<row-1:
				free_spots[y+1][x]=2
				taken_list.append([x,y+1])
			if y>0:
				free_spots[y-1][x]=2
				taken_list.append([x,y-1])
			x +=1
	elif axis_orientation=="vertical":
		if y>0:
			free_spots[y-1][x]=2
			taken_list.append([x,y-1])
			if x >0:
				free_spots[y-1][x-1]=2
				taken_list.append([x-1,y-1])
			if x <col-1:
				free_spots[y-1][x+1]=2
				taken_list.append([x+1,y-1])
		if b<=row-1:
			free_spots[b][x]=2
			taken_list.append([x,b])
			if x >0:
				free_spots[b][x-1]=2
				taken_list.append([x-1,b])
			if x <col-1:
				free_spots[b][x+1]=2
				taken_list.append([x+1,b])
		while y<b:
			free_spots[y][x]=1
			if x<col-1:
				free_spots[y][x+1]=2
				taken_list.append([x+1,y])
			if x>0:
				free_spots[y][x-1]=2
				taken_list.append([x-1,y])
			y +=1
	return taken_list
		
#print(taken(1,0,8,"vertical"))
#print("",free_spots[0],"\n",free_spots[1],"\n",free_spots[2],"\n",free_spots[3],"\n",free_spots[4],"\n",free_spots[5],"\n",free_spots[6],"\n",free_spots[7],"\n",free_spots[8],"\n")

def is_free(size,x,y,axis_orientation):
	row=len(free_spots)
	col=len(free_spots[0])
	b=size+y
	a=size+x
	if axis_orientation == "vertical":
		while y<b:
			if free_spots[y][x]==0:
				y+=1
			else:
				return False
	elif axis_orientation == "horisontal":
		while x<a:
			if free_spots[y][x]==0:
				x+=1
			else:
				return False
	return True




def rightsize(size,x,y,axis_orientation):
	row=len(free_spots) #9
	col=len(free_spots[0]) #7
	b=size+y
	a=size+x
	if axis_orientation == "vertical":
		if b>row:
			return False
		if x>col-1:
			return False
	elif axis_orientation == "horisontal":
		if a>col:
			return False
		if y>row-1:
			return False
	return True

#print(rightsize(1,1,0,"vertical"))
#print(rightsize(1,0,1,"vertical"))
#print(rightsize(1,1,0,"horisontal"))
#print(rightsize(1,0,1,"horisontal"))




def place_a_ship(size):
	row=len(free_spots)
	col=len(free_spots[0])
	x = random.randint(0,col-size)
	y = random.randint(0,row-size)
	
	orientation = random.randint(0,1)
	if orientation==0:
		axis_orientation = "vertical"
	else:
		axis_orientation = "horisontal"
	
	if rightsize(size,x,y,axis_orientation)== True:
		if is_free(size,x,y,axis_orientation) == True:
			taken(size,x,y,axis_orientation)
			return [x,y, axis_orientation,size]
		else:
			return place_a_ship(size)
	else:
		return place_a_ship(size)




#row=len(free_spots)
#col=len(free_spots[0])
#x = random.randint(0,col)
#y = random.randint(0,row)
#print(x,y)
#print(rightsize(1,9,6,"vertical"))

#print(place_a_ship(5))
#print(place_a_ship(4))
#print(place_a_ship(3))
#print(place_a_ship(2))
#print(place_a_ship(1))

#print("",free_spots[0],"\n",free_spots[1],"\n",free_spots[2],"\n",free_spots[3],"\n",free_spots[4],"\n",free_spots[5],"\n",free_spots[6],"\n",free_spots[7],"\n",free_spots[8],"\n")











